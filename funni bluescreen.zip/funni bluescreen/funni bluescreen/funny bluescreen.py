import os
import pygame
from pygame.locals import *
import sys
import requests


def create_directory(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)


def download_file(url, save_path):
    response = requests.get(url, stream=True)
    if response.status_code == 200:
        with open(save_path, 'wb') as f:
            f.write(response.content)
        print(f"Downloaded file to: {save_path}")
    else:
        print(f"Failed to download file from {url}")


pygame.init()


screen_width = 800
screen_height = 600
flags = FULLSCREEN | NOFRAME  # Combine flags for fullscreen and no frame
screen = pygame.display.set_mode((screen_width, screen_height), flags)
pygame.display.set_caption('Windows Crash Simulation')


documents_path = os.path.join(os.path.expanduser('~'), 'Documents')
simulation_folder = os.path.join(documents_path, 'BSOD_Simulation')
image_filename = 'sad_face.png'
image_path = os.path.join(simulation_folder, image_filename)


create_directory(simulation_folder)

image_url = 'https://drive.google.com/uc?export=download&id=1Hk9z0ZvJVRdYYEBo8UaN2AA-Msm7w-sA'

if not os.path.exists(image_path):
    download_file(image_url, image_path)


if os.path.exists(image_path):
    sad_face_image = pygame.image.load(image_path).convert_alpha()
    sad_face_image = pygame.transform.scale(sad_face_image, (screen_width, screen_height))  


running = True
while running:
  
    for event in pygame.event.get():
        if event.type == QUIT:
            pass  
        elif event.type == KEYDOWN:
            if event.key == K_KP1:  # Check for numpad 1 press
                running = False  # Exit the loop and the program

    
    screen.blit(sad_face_image, (0, 0))

    
    pygame.display.flip()


pygame.quit()
sys.exit()
